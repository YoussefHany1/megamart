import './cart.css';

function Cart() {
    return (
    <>

    </>
    );
}

export default Cart;
